# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.error_model import ErrorModel  # noqa: E501
from swagger_server.models.new_pet import NewPet  # noqa: E501
from swagger_server.models.pet import Pet  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDefaultController(BaseTestCase):
    """DefaultController integration test stubs"""

    def test_dodaj_zwierzaka(self):
        """Test case for dodaj_zwierzaka

        
        """
        pet = NewPet()
        response = self.client.open(
            '/zoo/pets',
            method='POST',
            data=json.dumps(pet),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_pokaz_zwierzeta(self):
        """Test case for pokaz_zwierzeta

        
        """
        query_string = [('gatunki', 'gatunki_example'),
                        ('limit', 56)]
        response = self.client.open(
            '/zoo/pets',
            method='GET',
            content_type='application/json',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_usun_zwierze(self):
        """Test case for usun_zwierze

        
        """
        response = self.client.open(
            '/zoo/pets/{id}'.format(id=789),
            method='DELETE',
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_znajdz_po_id(self):
        """Test case for znajdz_po_id

        
        """
        response = self.client.open(
            '/zoo/pets/{id}'.format(id=789),
            method='GET',
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
