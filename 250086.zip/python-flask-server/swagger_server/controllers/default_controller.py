import connexion
import six

from swagger_server.models.error_model import ErrorModel  # noqa: E501
from swagger_server.models.new_pet import NewPet  # noqa: E501
from swagger_server.models.pet import Pet  # noqa: E501
from swagger_server import util

import mysql.connector
import json

mydb = mysql.connector.connect(
            host="192.168.2.11",
            user="adminZoo",
            passwd="zaq1@WSX",
            database="zoo"
            )


def dodaj_zwierzaka(pet):  # noqa: E501
    """dodaj_zwierzaka

    Dodaje nowego zwierzaka do sklepu # noqa: E501

    :param pet: Zwięrzę do dodania do sklepu
    :type pet: dict | bytes

    :rtype: Pet
    """
    if connexion.request.is_json:
        zwierzak = connexion.request.get_json()  # noqa: E501
 
        mycursor = mydb.cursor()

        sql = "INSERT INTO Zwierzaki (imie, gatunek, kolor) VALUES (%s, %s, %s)"

        imie = zwierzak["imie"]
        gatunek = zwierzak["gatunek"]
        kolor = zwierzak["kolor"]
        
        val = (imie, gatunek, kolor)
        mycursor.execute(sql, val)

        mydb.commit()

        return "Wlasnie dodales zwierzaka"

    return "Chyba cos poszło nie tak"


def pokaz_zwierzeta(gatunki=None, limit=None):  # noqa: E501
    """pokaz_zwierzeta

    Zwraca wszystkie zwierzęta ze sklepu # noqa: E501

    :param gatunki: gatunki do szukania
    :type gatunki: List[str]
    :param limit: maksymalna liczba zwróconych zwierząt
    :type limit: int

    :rtype: List[Pet]
    """
    mycursor = mydb.cursor()
    sql = "SELECT * FROM Zwierzaki"

    if gatunki:
        sql += " WHERE gatunek = "
        for g in gatunki:
            sql += "\""
            sql += str(g)
            sql += "\""
            sql += " OR gatunek = "
        sql = sql[:-14]
        
    if limit:
        sql += " LIMIT "
        sql += str(limit)

    mycursor.execute(sql)
    res = mycursor.fetchall()

    return res


def usun_zwierze(id):  # noqa: E501
    """usun_zwierze

    Usuwa zwierzaka po ID # noqa: E501

    :param id: ID zwierzaka
    :type id: int

    :rtype: None
    """
    mycursor = mydb.cursor()
    sql = "DELETE FROM Zwierzaki WHERE id ="
    sql += str(id)
    mycursor.execute(sql)
    mydb.commit()
    res = "Usunieto zwierzaka o id "
    res += str(id)
    return res


def znajdz_po_id(id):  # noqa: E501
    """znajdz_po_id

    Zwraca zwierzaka po id # noqa: E501

    :param id: ID zwierzaka
    :type id: int

    :rtype: Pet
    """
    mycursor = mydb.cursor()

    sql = "SELECT * FROM Zwierzaki WHERE id = "
    sql += str(id)
    mycursor.execute(sql)
    res = mycursor.fetchall()

    return res
